﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;

/**
 ** auth:yadong
 ** data:2017年10月13日16:58:49
 ** mail:wuyd_w@163.com
 **
 **/

namespace WindowsFormsDrawTool
{
    public partial class Form1 : Form
    {
        private string editFileName;
        private Image theImage;
        private Graphics ig;
        private Color foreColor = Color.Black;
        private Color backColor = Color.White;
        private Point starPoint, oldPoint;
        private bool isDrawing = false;

        private enum DrawTools
        {
            Pen = 0,Line,Ellipse,Rectangle,String,Rubber,None
        }

        private DrawTools drawTool = DrawTools.None;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void OpenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image.Files(*.bmp;*.jpg;*.ioc;*.bmp)|*.bmp;*.jpg;*.ioc;*.bmp";
            openFileDialog1.Multiselect = false;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                this.Text = "DrawTool  MyDraw\t " + openFileDialog1.FileName;
                editFileName = openFileDialog1.FileName;
                theImage = Image.FromFile(openFileDialog1.FileName);
                Graphics g = this.CreateGraphics();
                g.DrawImage(theImage, this.ClientRectangle);
                ig = Graphics.FromImage(theImage);
                ig.DrawImage(theImage, this.ClientRectangle);
                toolStrip1.Enabled = true;
            }
        }

        private void ColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                foreColor = colorDialog1.Color;
            }
        }

        private void CreateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            g.Clear(backColor);
            toolStrip1.Enabled = true;
            theImage = new Bitmap(this.ClientRectangle.Width, this.ClientRectangle.Height);
            editFileName = "新建文件";
            this.Text = "DrawTool  MyDraw\t " + editFileName;
            ig = Graphics.FromImage(theImage);
            ig.Clear(backColor);
        }

        private void SaveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (theImage == null)
            {
                MessageBox.Show("未创建图像");
                return;
            }
            saveFileDialog1.Filter = "图像(*.bmp)|*.bmp";
            saveFileDialog1.FileName = editFileName;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                theImage.Save(saveFileDialog1.FileName, ImageFormat.Bmp);
                this.Text = "DrawTool  MyDraw\t " + saveFileDialog1.FileName;
                editFileName = saveFileDialog1.FileName;
            }
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            drawTool = DrawTools.Pen;
        }

        private void ToolStripButton2_Click(object sender, EventArgs e)
        {
            drawTool = DrawTools.Line;
        }

        private void ToolStripButton4_Click_1(object sender, EventArgs e)
        {
            drawTool = DrawTools.Ellipse;
        }

        private void ToolStripButton3_Click(object sender, EventArgs e)
        {
            drawTool = DrawTools.Rectangle;
        }
        private void ToolStripButton5_Click(object sender, EventArgs e)
        {
            drawTool = DrawTools.String;
        }

        private void ToolStripButton7_Click(object sender, EventArgs e)
        {
            drawTool = DrawTools.Rubber;
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDrawing = true;
                starPoint = new Point(e.X, e.Y);
                oldPoint = new Point(e.X, e.Y);
                if (drawTool == DrawTools.String)
                {
                    Form2 form2 = new Form2();
                    form2.StartPosition = FormStartPosition.CenterScreen;
                    if (form2.ShowDialog() == DialogResult.OK)
                    {
                        Graphics g = this.CreateGraphics();
                        g.DrawString(form2.TextBox1.Text, new Font("隶书", 20), new SolidBrush(foreColor), new Point(e.X, e.Y));
                        ig.DrawString(form2.TextBox1.Text, new Font("隶书", 20), new SolidBrush(foreColor), new Point(e.X, e.Y));
                    }
                }
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            isDrawing = false;
            switch (drawTool)
            {
                case DrawTools.Line:
                    ig.DrawLine(new Pen(foreColor, 1), starPoint, new Point(e.X, e.Y));
                    break;
                case DrawTools.Rectangle:
                    ig.DrawRectangle(new Pen(foreColor, 1), starPoint.X, starPoint.Y, e.X - starPoint.X, e.Y - starPoint.Y);
                    break;
                case DrawTools.Ellipse:
                    ig.DrawEllipse(new Pen(foreColor, 1), starPoint.X, starPoint.Y, e.X - starPoint.X, e.Y - starPoint.Y);
                    break;
                case DrawTools.String:
                    break;
            }
           
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            Graphics g = this.CreateGraphics();
            if (isDrawing)
            {
                switch (drawTool)
                {
                    case DrawTools.None:
                        break;
                    case DrawTools.Pen:
                        g.DrawLine(new Pen(foreColor, 1), oldPoint, new Point(e.X, e.Y));
                        ig.DrawLine(new Pen(foreColor, 1), oldPoint, new Point(e.X, e.Y));
                        oldPoint.X = e.X;
                        oldPoint.Y = e.Y;
                        break;
                    case DrawTools.Line:
                        this.Form1_Paint(this, new PaintEventArgs(this.CreateGraphics(), this.ClientRectangle));
                        g.DrawLine(new Pen(foreColor, 1), starPoint, new Point(e.X, e.Y));
                        break;
                    case DrawTools.Ellipse:
                        this.Form1_Paint(this, new PaintEventArgs(this.CreateGraphics(), this.ClientRectangle));
                        g.DrawEllipse(new Pen(foreColor, 1), starPoint.X, starPoint.Y, e.X - starPoint.X, e.Y - starPoint.Y);
                        break;
                    case DrawTools.Rectangle:
                        this.Form1_Paint(this, new PaintEventArgs(this.CreateGraphics(), this.ClientRectangle));
                        g.DrawRectangle(new Pen(foreColor, 1), starPoint.X, starPoint.Y, e.X - starPoint.X, e.Y - starPoint.Y);
                        break;
                    case DrawTools.Rubber:
                        g.DrawLine(new Pen(backColor, 20), oldPoint, new Point(e.X, e.Y));
                        ig.DrawLine(new Pen(backColor, 20), oldPoint, new Point(e.X, e.Y));
                        oldPoint.X = e.X;
                        oldPoint.Y = e.Y;
                        break;
                }
            }

        }
        
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (theImage != null)
            {
                Graphics g = this.CreateGraphics();
                g.Clear(backColor);
                g.DrawImage(theImage, this.ClientRectangle);
            }
        }
        
    }
}
