﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/**
 ** auth:yadong
 ** data:2017年10月6日13:35:27
 ** mail:wuyd_w@163.com
 **
 **/

namespace WindowsFormsTreeview
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TreeNode CountNode = new TreeNode("我的电脑");
            treeView_File.Nodes.Add(CountNode);
            listView_File.Columns.Add("名称", 300, HorizontalAlignment.Left);
            foreach (string DrvName in Directory.GetLogicalDrives())
            {
                CountNode.Nodes.Add(CreateTreeNode(DrvName));
            }
            foreach (string DrvName in Directory.GetLogicalDrives())
            {
                listView_File.Items.Add(new ListViewItem(DrvName));  
            }
        }

        private void treeView_File_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if(e.Node.Nodes.Count == 0)
            { 
                if (e.Node.Parent == null)
                {
                    foreach (string DrvName in Directory.GetLogicalDrives())
                    {
                        e.Node.Nodes.Add(CreateTreeNode(DrvName));
                    }
                }
                else
                {
                    if (Directory.Exists(e.Node.Tag.ToString()))
                    {
                        try
                        {
                            foreach (string DrvName in Directory.GetDirectories(e.Node.Tag.ToString()))
                            {
                                e.Node.Nodes.Add(CreateTreeNode(DrvName));
                            }
                        }
                        catch (UnauthorizedAccessException) {
                            MessageBox.Show("权限不足");
                            return;
                        }
                       
                    }
                    ListView_show(e.Node.Text);
                }
            }
            if (e.Node.Parent == null)
            {
                listView_File.Items.Clear();
                foreach (string DrvName in Directory.GetLogicalDrives())
                {
                    listView_File.Items.Add(new ListViewItem(DrvName));
                }
            }
        }

        private void listView_File_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            ListView_show(listView_File.FocusedItem.Text);
        }

        private void ListView_show(string DirText)
        {
            if (Directory.Exists(DirText))
            {
                listView_File.Items.Clear();
                try
                {
                    foreach (string DirName in Directory.GetDirectories(DirText))
                    {
                        listView_File.Items.Add(new ListViewItem(DirName));
                    }
                    foreach (string FileName in Directory.GetFiles(DirText))
                    {
                        listView_File.Items.Add(new ListViewItem(FileName));
                    }
                }
                catch (UnauthorizedAccessException)
                {
                    MessageBox.Show("权限不足");
                    return;
                }
            
            }
        }

        private TreeNode CreateTreeNode(string DrvName)
        {
            TreeNode treeNode = new TreeNode(DrvName);
            treeNode.Tag = DrvName;
            return treeNode;
        }
    }
}
