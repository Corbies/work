﻿namespace WindowsFormsTreeview
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.listView_File = new System.Windows.Forms.ListView();
            this.treeView_File = new System.Windows.Forms.TreeView();
            this.SuspendLayout();
            // 
            // listView_File
            // 
            this.listView_File.GridLines = true;
            this.listView_File.Location = new System.Drawing.Point(342, 12);
            this.listView_File.Name = "listView_File";
            this.listView_File.Size = new System.Drawing.Size(318, 439);
            this.listView_File.TabIndex = 0;
            this.listView_File.UseCompatibleStateImageBehavior = false;
            this.listView_File.View = System.Windows.Forms.View.Details;
            this.listView_File.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView_File_MouseDoubleClick);
            // 
            // treeView_File
            // 
            this.treeView_File.Location = new System.Drawing.Point(12, 12);
            this.treeView_File.Name = "treeView_File";
            this.treeView_File.Size = new System.Drawing.Size(324, 439);
            this.treeView_File.TabIndex = 1;
            this.treeView_File.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView_File_NodeMouseClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(672, 463);
            this.Controls.Add(this.treeView_File);
            this.Controls.Add(this.listView_File);
            this.Name = "Form1";
            this.Opacity = 0.95D;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listView_File;
        private System.Windows.Forms.TreeView treeView_File;
    }
}

